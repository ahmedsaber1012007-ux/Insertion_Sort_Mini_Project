"""
Mini Project: Empirical Analysis of Insertion Sort
Run: python main.py
Outputs: results/experiment_results.csv and charts/*.png
"""

import csv
import random
import time
from pathlib import Path

SIZES = [100, 500, 1000, 2000, 3000, 4000, 5000]
INPUT_TYPES = ["Sorted", "Reverse-sorted", "Random"]
ROOT = Path(__file__).resolve().parent
RESULTS_DIR = ROOT / "results"
CHARTS_DIR = ROOT / "charts"


def insertion_sort(values):
    """Sort values in ascending order and count comparisons and shifts."""
    arr = values.copy()
    comparisons = 0
    shifts = 0

    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1

        # Count each comparison between arr[j] and key.
        while j >= 0:
            comparisons += 1
            if arr[j] > key:
                arr[j + 1] = arr[j]
                shifts += 1
                j -= 1
            else:
                break

        arr[j + 1] = key

    return arr, comparisons, shifts


def make_input(size, input_type, rng):
    if input_type == "Sorted":
        return list(range(size))
    if input_type == "Reverse-sorted":
        return list(range(size, 0, -1))
    values = list(range(size))
    rng.shuffle(values)
    return values


def main():
    RESULTS_DIR.mkdir(exist_ok=True)
    CHARTS_DIR.mkdir(exist_ok=True)
    rng = random.Random(42)  # Fixed seed makes the random experiment reproducible.
    rows = []

    for input_type in INPUT_TYPES:
        for size in SIZES:
            data = make_input(size, input_type, rng)

            start = time.perf_counter()
            sorted_data, comparisons, shifts = insertion_sort(data)
            elapsed_ms = (time.perf_counter() - start) * 1000

            assert sorted_data == sorted(data), "Sorting result is incorrect."
            rows.append({
                "input_type": input_type,
                "n": size,
                "time_ms": round(elapsed_ms, 4),
                "comparisons": comparisons,
                "shifts": shifts,
            })
            print(
                f"{input_type:16} n={size:4} | "
                f"time={elapsed_ms:10.4f} ms | "
                f"comparisons={comparisons:10} | shifts={shifts:10}"
            )

    csv_path = RESULTS_DIR / "experiment_results.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(
            file, fieldnames=["input_type", "n", "time_ms", "comparisons", "shifts"]
        )
        writer.writeheader()
        writer.writerows(rows)

    # Make charts if matplotlib is installed.
    try:
        import matplotlib.pyplot as plt

        for input_type in INPUT_TYPES:
            selected = [row for row in rows if row["input_type"] == input_type]
            plt.figure()
            plt.plot(
                [row["n"] for row in selected],
                [row["time_ms"] for row in selected],
                marker="o",
                label="Measured runtime",
            )
            plt.xlabel("Input size (n)")
            plt.ylabel("Runtime (milliseconds)")
            plt.title(f"Insertion Sort - {input_type} input")
            plt.grid(True)
            plt.legend()
            plt.tight_layout()
            safe_name = input_type.lower().replace("-", "_")
            plt.savefig(CHARTS_DIR / f"{safe_name}_runtime.png", dpi=160)
            plt.close()

        # Combined comparison chart
        plt.figure()
        for input_type in INPUT_TYPES:
            selected = [row for row in rows if row["input_type"] == input_type]
            plt.plot(
                [row["n"] for row in selected],
                [row["time_ms"] for row in selected],
                marker="o",
                label=input_type,
            )
        plt.xlabel("Input size (n)")
        plt.ylabel("Runtime (milliseconds)")
        plt.title("Insertion Sort Runtime Comparison")
        plt.grid(True)
        plt.legend()
        plt.tight_layout()
        plt.savefig(CHARTS_DIR / "runtime_comparison.png", dpi=160)
        plt.close()
        print(f"\nResults saved to: {csv_path}")
        print(f"Charts saved to: {CHARTS_DIR}")
    except ImportError:
        print("\nmatplotlib is not installed. Install it with: pip install matplotlib")
        print("CSV results were still saved.")


if __name__ == "__main__":
    main()
