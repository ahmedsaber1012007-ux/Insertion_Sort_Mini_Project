# Mini Project: Empirical Analysis of Insertion Sort

## Project contents
- `main.py`: implements Insertion Sort and counts comparisons and shifts.
- `results/experiment_results.csv`: measured experiment results.
- `charts/`: runtime charts for sorted, reverse-sorted, random, and combined inputs.
- `report.md`: one-page report summarizing the findings.

## Requirements
- Python 3.9 or newer
- matplotlib (for charts)

## How to run
1. Install Python if it is not already installed.
2. Open a terminal in this project folder.
3. Install chart support:
   ```bash
   python -m pip install matplotlib
   ```
4. Run:
   ```bash
   python main.py
   ```

The program tests n = 100, 500, 1000, 2000, 3000, 4000, and 5000 for sorted,
reverse-sorted, and random input. It checks that each output is correctly sorted.
The random generator uses a fixed seed so the experiment can be reproduced.

## Notes
- Runtime varies by computer and should be measured on the machine used for submission.
- The CSV and charts are regenerated each time `main.py` runs.
