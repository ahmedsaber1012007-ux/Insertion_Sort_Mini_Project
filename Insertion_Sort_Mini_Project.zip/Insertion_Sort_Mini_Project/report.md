# Empirical Analysis of Insertion Sort

## Objective
This experiment evaluates Insertion Sort for input sizes from 100 to 5,000 using sorted, reverse-sorted, and random arrays. The program records runtime, key comparisons, and shifts.

## Method
The algorithm was implemented in Python. Each test used a copied input array, and correctness was checked by comparing the output with Python's sorted result. Runtime was measured with `time.perf_counter()`. Random inputs used a fixed seed for reproducibility.

## Results and discussion
For sorted input, Insertion Sort performs approximately n−1 comparisons and no shifts; at n=5,000 the experiment recorded 4,999 comparisons and 0 shifts. For reverse-sorted input, each element must move past the previous elements; at n=5,000 it recorded 12,497,500 comparisons and 12,497,500 shifts. The random case recorded 6,345,469 comparisons and 6,340,474 shifts. The charts and CSV contain the measured runtimes for all tested sizes. Runtime values depend on the computer and current system load.

## Complexity and comparison
Insertion Sort has best-case time complexity O(n) for already sorted data, and average- and worst-case time complexity O(n²). Merge Sort runs in O(n log n) time in best, average, and worst cases, so it is generally more suitable for large datasets. Insertion Sort can still be efficient for small or nearly sorted arrays because it is simple and uses O(1) extra space.

## Conclusion
The experiment demonstrates that input order strongly affects Insertion Sort. Sorted input is much cheaper than reverse-sorted input, while growth on random and reverse-sorted inputs becomes steep as n increases. Merge Sort offers more predictable scalability for large inputs.
